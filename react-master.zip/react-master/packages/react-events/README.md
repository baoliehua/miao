# `react-events`

This is package is intended for use with the experimental React events API.